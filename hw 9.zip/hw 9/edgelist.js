const edgelist = [
    {
        "source": "Jim",
        "target": "Irene",
        "weight": 5
    },
    {
        "source": "Susie",
        "target": "Irene",
        "weight": 5
    },
    {
        "source": "Jim",
        "target": "Susie",
        "weight": 5
    },
    {
        "source": "Susie",
        "target": "Kai",
        "weight": 5
    },
    {
        "source": "Shirley",
        "target": "Kai",
        "weight": 5
    },
    {
        "source": "Shelby",
        "target": "Kai",
        "weight": 5
    },
    {
        "source": "Kai",
        "target": "Susie",
        "weight": 5
    },
    {
        "source": "Kai",
        "target": "Shirley",
        "weight": 5
    },
    {
        "source": "Kai",
        "target": "Shelby",
        "weight": 5
    },
    {
        "source": "Erik",
        "target": "Zan",
        "weight": 5
    },
    {
        "source": "Tony",
        "target": "Zan",
        "weight": 5
    },
    {
        "source": "Tony",
        "target": "Fil",
        "weight": 5
    },
    {
        "source": "Tony",
        "target": "Ian",
        "weight": 5
    },
    {
        "source": "Tony",
        "target": "Adam",
        "weight": 5
    },
    {
        "source": "Fil",
        "target": "Tony",
        "weight": 4
    },
    {
        "source": "Ian",
        "target": "Miles",
        "weight": 1
    },
    {
        "source": "Adam",
        "target": "Tony",
        "weight": 3
    },
    {
        "source": "Miles",
        "target": "Ian",
        "weight": 2
    },
    {
        "source": "Miles",
        "target": "Ian",
        "weight": 3
    },
    {
        "source": "Erik",
        "target": "Kai",
        "weight": 2
    },
    {
        "source": "Erik",
        "target": "Nadieh",
        "weight": 2
    },
    {
        "source": "Jim",
        "target": "Nadieh",
        "weight": 2
    }
]