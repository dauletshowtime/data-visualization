<template>
	<button class="btn" :class="`btn-${type}`">
		<slot></slot>
	</button>
</template>

<script>
export default {
	name: 'TheButton',
	props: {
		type: {
			type: String,
			default: 'primary',
			validator(value) {
				return ['primary', 'secondary'].includes(value);
			}
		}
	}
};
</script>

<style scoped>
.btn {
	border: none;
	padding: 0.5rem 0.8rem;
	box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
	border-radius: 0.25rem;
	cursor: pointer;
	transition: all 0.2s ease-in-out;
}

.btn-primary {
	background-color: #181818;
	color: #fff;
}

.btn-secondary {
	background-color: #e2e8f0;
	color: #1a202c;
}

.btn:hover {
	box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1), 0 2px 3px 0 rgba(0, 0, 0, 0.06);
}

.btn:active {
	box-shadow: 0 0 0 0 rgba(0, 0, 0, 0.1), 0 0 0 0 rgba(0, 0, 0, 0.06);
}

.btn:focus {
	outline: none;
	box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.5);
}

.btn:disabled {
	opacity: 0.5;
	cursor: not-allowed;
}
</style>
