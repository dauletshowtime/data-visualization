<template>
	<select class="selector" @input="onSelect">
		<option
			v-for="(value, key) in SORT_TYPES"
			:key="key"
			:value="key"
			:selected="key === sortType"
		>
			{{ value }}
		</option>
	</select>
</template>

<script>
import { computed } from 'vue';
import store from '@/store';
import { SORT_TYPES } from '@/utils/constants';

export default {
	name: 'SortSelector',
	setup() {
		const sortType = computed(() => store.state.sortType);
		const onSelect = event => store.changeSortType(event.target.value);

		return {
			sortType,
			onSelect,
			SORT_TYPES
		};
	}
};
</script>

<style scoped>
.selector {
	padding: 0.5rem 1rem;
	border: 1px solid #e2e8f0;
	border-radius: 0.25rem;
	width: 100%;
}

.selector:focus {
	outline: none;
	box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.5);
}

.selector:disabled {
	opacity: 0.5;
	cursor: not-allowed;
}
</style>
