<template>
	<div class="sort-elements">
		<TransitionGroup name="fade">
			<div
				v-for="number in numbers"
				:key="number"
				class="sort-element"
				:class="{
					'sort-element--current': number === current,
					'sort-element--next': number === next
				}"
				:style="{ height: `${100 + number * 2}px` }"
			>
				<div class="sort-element__number">
					{{ number }}
				</div>
			</div>
		</TransitionGroup>
	</div>
</template>

<script>
import { computed } from 'vue';
import store from '@/store';

export default {
	name: 'SortElements',
	setup() {
		const numbers = computed(() => store.state.numbersArray);
		const current = computed(() => store.state.currentNumber);
		const next = computed(() => store.state.nextNumber);

		return {
			numbers,
			current,
			next
		};
	}
};
</script>

<style scoped>
.sort-elements {
	display: flex;
	padding: 1rem 0;
}

.sort-element {
	width: 30px;
	height: 200px;
	margin-right: 0.5rem;
	background-color: #181818;
	transform-origin: bottom;
	transition: transform 50ms ease;
}

.sort-element:last-child {
	margin-right: 0;
}

.sort-element__number {
	width: 100%;
	height: 30px;
	line-height: 30px;
	text-align: center;
	color: #fff;
}

.sort-element--current {
	background-color: #047857;
}

.sort-element--next {
	background-color: #1e3a8a;
}

/* fade transition */
.fade-move,
.fade-enter-active,
.fade-leave-active {
	transition: all 0.5s cubic-bezier(0.86, 0, 0.07, 1);
}

.fade-enter-from,
.fade-leave-to {
	opacity: 0;
	transform: scaleY(0.01) translate(30px, 0);
}

.fade-leave-active {
	position: absolute;
}
</style>
