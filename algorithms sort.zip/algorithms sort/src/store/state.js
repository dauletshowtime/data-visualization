import { reactive } from 'vue';
import { SORT_TYPES } from '@/utils/constants';

export default reactive({
	sortType: Object.keys(SORT_TYPES)[0],
	numbersArray: Array.from({ length: 14 }, (_, i) => i + 1),
	currentNumber: 0,
	nextNumber: 0,
	isLoading: false
});
