import { readonly } from 'vue';
import state from './state';
import {
	sortBubble,
	sortCocktail,
	sortSelection,
	sortInsertion,
	sortMerge,
	sortQuick,
	sortTree
} from '@/utils/functions';

const SORT_ALGORITHM = {
	bubble: sortBubble,
	cocktail: sortCocktail,
	selection: sortSelection,
	insertion: sortInsertion,
	merge: sortMerge,
	quick: sortQuick,
	tree: sortTree
};
// тут их можно объединить в один объект, пока так оставлю
const setCurrent = number => (state.currentNumber = number);
const setNext = number => (state.nextNumber = number);
const clear = () => {
	state.currentNumber = 0;
	state.nextNumber = 0;
};

export default {
	state: readonly(state),
	changeSortType: type => (state.sortType = type),
	shuffle: () => {
		const array = state.numbersArray;
		let currentIndex = array.length,
			randomIndex;

		while (currentIndex !== 0) {
			randomIndex = Math.floor(Math.random() * currentIndex);
			currentIndex--;

			[array[currentIndex], array[randomIndex]] = [
				array[randomIndex],
				array[currentIndex]
			];
		}

		return array;
	},
	sort: () => {
		const algorithm = SORT_ALGORITHM[state.sortType];
		state.isLoading = true;
		algorithm(state.numbersArray, { setCurrent, setNext, clear }).then(
			() => (state.isLoading = false)
		);
	}
};
