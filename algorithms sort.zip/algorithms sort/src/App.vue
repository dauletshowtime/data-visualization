<template>
	<div class="app container">
		<h1 class="title">Алгоритмы сортировки</h1>
		<SortSelector />

		<div class="app__btn-container">
			<TheButton :disabled="isLoading" @click="sort">Сортировать</TheButton>
			<TheButton @click="shuffle">Смешать</TheButton>
		</div>

		<SortElements />
	</div>
</template>

<script>
import { computed } from 'vue';
import TheButton from '@/components/TheButton.vue';
import SortSelector from '@/components/SortSelector.vue';
import SortElements from '@/components/SortElements.vue';
import store from '@/store';

export default {
	name: 'App',
	components: {
		TheButton,
		SortSelector,
		SortElements
	},
	setup() {
		const isLoading = computed(() => store.state.isLoading);

		return {
			sort: store.sort,
			shuffle: store.shuffle,
			isLoading
		};
	}
};
</script>

<style scoped>
.app__btn-container {
	display: flex;
	justify-content: space-between;
	padding: 1rem 0;
	width: 200px;
}
</style>
