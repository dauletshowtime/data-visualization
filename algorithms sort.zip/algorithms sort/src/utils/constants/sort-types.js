export default {
	bubble: 'Пузырьком🫧',
	cocktail: 'Перемешиванием🥗',
	selection: 'Выбором💅🏻',
	insertion: 'Вставками🍢',
	merge: 'Слиянием🌕',
	quick: 'Быстрая сортировка💨',
	tree: 'Деревом🌳'
};
