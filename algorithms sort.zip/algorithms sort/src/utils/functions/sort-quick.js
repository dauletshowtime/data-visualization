export default async function (array, controllers) {
	let delay = 300;

	const partition = async (array, low, high) => {
		let pivot = array[high];
		let i = low - 1;
		for (let j = low; j < high; j++) {
			if (array[j] < pivot) {
				i++;
				const temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			}
			controllers.setCurrent(array[j]);
			controllers.setNext(array[i]);
			await new Promise(resolve => setTimeout(resolve, delay));
		}
		const temp = array[i + 1];
		array[i + 1] = array[high];
		array[high] = temp;
		return i + 1;
	};

	const quickSort = async (array, low, high) => {
		if (low < high) {
			let pi = await partition(array, low, high);
			await quickSort(array, low, pi - 1);
			await quickSort(array, pi + 1, high);
		}
	};

	await quickSort(array, 0, array.length - 1);
	controllers.clear();
}
