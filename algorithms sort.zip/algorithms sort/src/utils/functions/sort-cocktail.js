import store from '@/store';

export default async function (array) {
	let delay = 300;
	let left = 0;
	let right = array.length - 1;

	while (left < right) {
		for (let i = left; i < right; i++) {
			if (array[i] > array[i + 1]) {
				const temp = array[i];
				array[i] = array[i + 1];
				array[i + 1] = temp;

				store.setCurrent(array[i]);
				store.setNext(array[i + 1]);
			}
			await new Promise(resolve => setTimeout(resolve, delay));
		}
		right--;

		for (let i = right; i > left; i--) {
			if (array[i] < array[i - 1]) {
				const temp = array[i];
				array[i] = array[i - 1];
				array[i - 1] = temp;

				store.setCurrent(array[i]);
				store.setNext(array[i + 1]);
			}
			await new Promise(resolve => setTimeout(resolve, delay));
		}
		left++;
	}

	store.clear();
}
